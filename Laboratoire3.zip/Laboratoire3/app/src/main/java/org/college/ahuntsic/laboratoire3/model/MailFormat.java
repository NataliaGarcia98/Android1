package org.college.ahuntsic.laboratoire3.model;

public class MailFormat {

    public final void formatMail(String mail) {

        final String regex = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";

    }
}
