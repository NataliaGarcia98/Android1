package org.college.ahuntsic.laboratoire3.model;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

import org.college.ahuntsic.laboratoire3.R;

public class SecondActivity extends AppCompatActivity {

    EditText editFirstname;
    EditText editName;
    EditText editPhone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    EditText editMail;

        editFirstname = findViewById(R.id.editTextFirstName);
        editName = findViewById(R.id.editTextName);
        editPhone = findViewById(R.id.editTextPhone);
        editMail = findViewById(R.id.editTextMail);

        Intent intent = getIntent();
        if (intent != null){
            Contact contact = intent.getParcelableExtra("Contact");
            if (contact != null){
                editFirstname.setText(contact.getFirst_name());
                editName.setText(contact.getName());
                editPhone.setText(contact.getPhone());
                editMail.setText(contact.getMail());

            }
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_second, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save:

                String firstName = editFirstname.getText().toString();
                String name = editName.getText().toString();
                String mail = editMail.getText().toString();
                int phone = editPhone.getText().length();

                String sex = "Male";

                Contact contact = new Contact(firstName, name, 'M', phone, mail);

                Intent result = new Intent();
                result.putExtra("Contact", contact);
                setResult(Activity.RESULT_OK, result);
                finish();

                return true;
            case R.id.delete:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}