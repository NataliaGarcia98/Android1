package org.college.ahuntsic.laboratoire3.model;

import android.widget.EditText;

public class PhoneFormat {

    public static void formatPhone(EditText editText) {
    }
}
