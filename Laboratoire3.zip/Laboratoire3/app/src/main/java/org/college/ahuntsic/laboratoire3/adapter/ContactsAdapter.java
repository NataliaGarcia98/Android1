package org.college.ahuntsic.laboratoire3.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import org.college.ahuntsic.laboratoire3.R;
import org.college.ahuntsic.laboratoire3.model.Contact;
import java.util.List;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ViewHolder>  {
    private List<Contact> listContacts;
    private Context context;

    public ContactsAdapter() {

    }

    public void setListContacts(List<Contact> listContacts) {
        this.listContacts = listContacts;
    }

    private OnItemClickListener itemClickListener;

    public interface  OnItemClickListener{
        void onItemClick(Contact contact);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {

        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_row, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        Contact contact = listContacts.get(position);

        holder.textViewNom.setText(contact.getFirst_name() + " " +  contact.getName());
        holder.textViewPhone.setText(contact.getPhone());

    }

    @Override
    public int getItemCount() {
        return listContacts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView textViewNom;
        public TextView textViewPhone;

        public ViewHolder(View itemView) {
            super(itemView);

            textViewNom = (TextView) itemView.findViewById(R.id.nameView);
            textViewPhone = (TextView) itemView.findViewById(R.id.phoneView);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Contact contact = listContacts.get(position);
                    itemClickListener.onItemClick(contact);
                }
            }
        }
    }

}